// Put the pixelart to be table in a variable called "canvas"
const canvas = document.querySelector('#pixelCanvas');

// When size is submitted by the user, call makeGrid()
let pickedSize = document.querySelector('#sizePicker');
pickedSize.addEventListener('submit', makeGrid);


// Make table cells according to the size the user chose
function makeGrid(ev){

    //Stops the browser to automatically refresh
    ev.preventDefault();

    //Erase any table cells if they already exist
    while(canvas.firstChild){
        canvas.removeChild(canvas.firstChild);
    }

    // Select the size of the user input
    let height = document.querySelector('#inputHeight').value;
    let width = document.querySelector('#inputWidth').value;
    
    // Create table cells through loop
    for(let r = 0; r < height ; r++){
        let row = document.createElement('tr');    
        canvas.appendChild(row);
            
            for(let c = 0; c < width ; c++){
            let col = document.createElement('td');    
            row.appendChild(col);
            }
        }

}

// When one of the table cells is clicked, call colorChange function
canvas.addEventListener('click', colorChange);

// Change the background color of the clicked cell to the color the user chose
function colorChange(ev){
    const pickColor = document.querySelector('#colorPicker').value;
    ev.target.style.backgroundColor = pickColor;

}



